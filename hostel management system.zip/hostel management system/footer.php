
<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">
    	
        Connect with us-<br />
			 <a href="http://www.facebook.in" style="color:white">Facebook</a> <a href="http://www.quora.in" style="color:white">Quora</a> <a href="http://www.instagram.in" style="color:white">Instagram</a> <a href="http://www.twitter.in" style="color:white">Twitter</a> <a href="http://www.Linkedin.in" style="color:white">LinkedIn</a> <a href="http://www.Github.com" style="color:white">Github</a> <br /><br />
			 © Copyright 2018. All Rights Reserved.<br />
			 Terms of Use and Privacy Policy<br />
			 This webpage is to be licenced under open-source licence 2018.<br />
    
    </div> <!-- end of footer wrapper -->
</div> <!-- end of footer -->

</body>
</html>