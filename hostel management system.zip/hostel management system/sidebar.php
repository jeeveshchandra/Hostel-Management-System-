<?php
session_start();
include("databaseconnection.php");
?>
<!--
            	<h2><u>Menu</u></h2>
                <h2><a href="dashboard.php">Home</a></h2>
                <h2><a href="employee.php">Change Profile</a></h2>
                <h2><a href="changepassword.php">Change password</a></h2>
                 <h2><a href="employee.php">Add Employee</a></h2>
                 <h2><a href="viewemployee.php">View Employee</a></h2>
                 <h2><a href="course.php">Add Course</a></h2>                 
                 <h2><a href="viewcourse.php">View Course</a></h2>                 
                 <h2><a href="blocks.php">Add Blocks</a></h2>
                 <h2><a href="viewblocks.php">View Blocks</a></h2>
                 <h2><a href="rooms.php">Add Rooms</a></h2>
                 <h2><a href="viewrooms.php">View Rooms</a></h2>
                 <h2><a href="roomallotment.php">Allot Rooms</a></h2>
                 <h2><a href="students.php">Add Student</a></h2>
                 <h2><a href="viewstudents.php">View Students</a></h2>
                 <h2><a href="feetype.php">Fees Structure</a></h2>
                 <h2><a href="viewfees.php">View Fees</a></h2>
                 <h2><a href="viewmessbill.php">View Messbill</a></h2>
                 <h2><a href="viewbilling.php">View Billing</a></h2>
                 <h2><a href="logout.php">Logout</a></h2>
-->