<?php
include("header.php");

?>
    
    <div id="templatemo_middle_subpage">
    	<h2>Contact Us</h2>
        <p>tap to know more <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
  </div>
        
    <div id="templatemo_main">

        <div class="col_w900 col_w900_last">
        
            <div class="col_w420 float_l">
            
           	  <h3>Contact Form</h3>
              
              	<div id="cp_contact_form">
                    
                    <form method="post" name="contact" action="#">
                    
                            <label for="author">Name:</label> <input name="author" type="text" class="input_field" id="author" maxlength="60" />
                          	<div class="cleaner_h10"></div>
                            
                            <label for="email">Email:</label> <input name="email" type="text" class="input_field" id="email" maxlength="60" />
                          	<div class="cleaner_h10"></div>
                            
                            <label for="subject">Subject:</label> <input name="subject" type="text" class="input_field" id="subject" maxlength="60" />
                            <div class="cleaner_h10"></div>

                            <label for="text">Message:</label> <textarea id="text" name="text" rows="0" cols="0" class="required"></textarea>
                            <div class="cleaner_h10"></div>
                            
                            <input type="submit" class="submit_btn float_l" name="submit" id="submit" value="Send" />
                            <input type="reset" class="submit_btn float_r" name="reset" id="reset" value="Reset" />
                        
                   </form>
    
                </div>
               
            </div>
            
            
                                
                <h3>Our Address</h3>
                
                	<h6>RJ group of management</h6>
                   	  	manit  <br />
                        hostel no-2<br />
						<br />
                		<br />
                     	Tel:7024874052<br />
                       
            </div>
            
            <div class="cleaner"></div>
		</div>
        
        <div class="cleaner"></div>
    </div> <!-- end of main -->
        
</div> <!-- end of wrapper -->

<?php
include("footer.php");
?>