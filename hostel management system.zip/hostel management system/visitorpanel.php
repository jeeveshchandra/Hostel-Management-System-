<?php
include("header.php");
?>
    <div id="templatemo_main">

        <div class="col_w900 col_w900_last">
        
<div class="col_w580 float_l">
            
            	<div class="post_box">
            	 
                    <h2>Visitor Panel</h2>
                  <p>
                  <img src="images/geehasuki/Visitor banner.jpg" width="867" height="359" /> </p>
                    <div class="cleaner"></div>
                </div>
</div>
            
         
            
            <div class="cleaner"></div>
		</div>
        
        <div class="cleaner"></div>
    </div> <!-- end of main -->
        
</div> <!-- end of wrapper -->


<?php
include("footer.php");
?>