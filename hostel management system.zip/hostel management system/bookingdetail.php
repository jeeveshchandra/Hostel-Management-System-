
<form>
<table>
<tr><th><div align="center">RECEIPT DATE</div></th></tr>
<tr><th rowspan=2>Booking no :</th></tr>
</table></form>