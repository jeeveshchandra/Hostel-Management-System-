<?php
$dbconnection=mysqli_connect("localhost","root","manit","hostelmanagementsystem");
if(!$dbconnection)
{
	echo "unable to establish connection to server";
}
?>
