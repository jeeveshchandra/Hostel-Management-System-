<?php
echo $_POST[sdate];
echo $_POST[edate];
?>