<?php
include("header.php");
?>
    
    <div id="templatemo_middle_subpage">
    	<h2>Blog Posts</h2>
        <p> </p>
  </div>
        
    <div id="templatemo_main">

        <div class="col_w900 col_w900_last">
        
<div class="col_w580 float_l">
            
            	<div class="post_box">
                    <img src="images/blog_image_02.jpg" alt="Image 1" />
                    <p class="post_meta"><span class="cat">Posted in <a href="#">CSS Templates</a>, <a href="#">Web Design</a></span></p>
                    <h2></h2>
                    <p> . Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong></strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                    <a class="more" href="#">Read More</a>
                    <div class="cleaner"></div>
                </div>
                
                <div class="post_box">
                    <img src="images/blog_image_03.jpg" alt="Image 2" />
                    <p class="post_meta"><span class="cat">Posted in <a href="#">Marketing</a>, <a href="#">Advertising</a></span></p>
                    <h2></h2>
                    <p> </p>
                    <a class="more" href="#">Read More</a>
                    <div class="cleaner"></div>
                </div>
                
                <div class="post_box">
                    <img src="images/blog_image_02.jpg" alt="Image 3" />
                  <p class="post_meta"><span class="cat">Posted in <a href="#">Illustrations</a>, <a href="#">Graphics</a></span> </p>
                  </p>
                    <a class="more" href="#">Read More</a>
                    <div class="cleaner"></div>
                </div>
                
<div class="post_box">
                    <img src="images/blog_image_01.jpg" alt="Image 4" />
                    <p class="post_meta"><span class="cat">Posted in <a href="#">3D</a>, <a href="#">Interactive</a></span> </p>
                  </p>
                    <a class="more" href="#">Read More</a>
                    <div class="cleaner"></div>
                </div>
           	  
            </div>
            
            <div class="col_w280 float_r">
            
            	<h2>Popular Posts</h2>
                
          		<div class="lbe_box">
                    <h3><a href="#"></a></h3>
                  <p></p>
                    <p class="date"></p>
                </div>
                
                <div class="lbe_box">
                    <h3><a href="#"></a></h3>
                    <p></p>
                    <p class="date"></p>
                    <div class="cleaner"></div>
                </div>
                
                <div class="cleaner h30"></div>
                
                
                
                <div class="sb_lp_box">
                	<img src="images/gallery/image_04_s.jpg" alt="image 5" />
                    <p><a href="#">More...</a></p>
                </div>
                
                <div class="sb_lp_box">
                	<img src="images/gallery/image_02_s.jpg" alt="image 6" />
                    <p> <a href="#">More...</a></p>
                </div>
                
                <div class="sb_lp_box">
                	<img src="images/gallery/image_03_s.jpg" alt="image 7" />
                    <p><a href="#">More...</a></p>
                </div>
                
            </div>
            
            <div class="cleaner"></div>
		</div>
        
        <div class="cleaner"></div>
    </div> <!-- end of main -->
        
</div> <!-- end of wrapper -->


<?php
include("footer.php");
?>