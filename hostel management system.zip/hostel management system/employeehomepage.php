<?php
include("header.php");
?>
    
    <div id="templatemo_middle_subpage">
    	<h2>Website Templates Gallery</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris iaculis nulla vitae ante congue iaculis. Nunc vitae sapien sed neque porttitor egestas sit amet ut ligula. Praesent placerat dui ut nibh eleifend lobortis. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
  </div>
        
    <div id="templatemo_main">

        <div class="col_w900 col_w900_last">
            <div id="gallery">
                <ul>
                    <li><a href="dashboard.php" title="Home"><img src="images/geehasuki/images.jpg" alt="Home" /></a></li>
                    <li>
                        <a href="images/gallery/image_02_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_02_s.jpg" alt="Image 2" />
                        </a>
                  </li>
                    <li>
                        <a href="images/gallery/image_03_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_03_s.jpg" alt="Image 3" />
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery/image_04_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_04_s.jpg" alt="Image 4" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="images/gallery/image_05_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_05_s.jpg" alt="Image 5" />
                        </a>
                    </li>

                    <li>
                        <a href="images/gallery/image_06_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_06_s.jpg" alt="Image 6" />
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery/image_04_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_04_s.jpg" alt="Image 7" />
                        </a>
                  </li>
                    <li>
                        <a href="images/gallery/image_05_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_05_s.jpg" alt="Image 8" />
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery/image_03_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_03_s.jpg" alt="Image 9" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="images/gallery/image_02_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_02_s.jpg" alt="Image 10" />
                        </a>
                    </li>

                    <li>
                        <a href="images/gallery/image_03_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_03_s.jpg" alt="Image 11" />
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery/image_01_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_01_s.jpg" alt="Image 12" />
                        </a>
                  </li>
                    <li>
                        <a href="images/gallery/image_02_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_02_s.jpg" alt="Image 13" />
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery/image_05_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_05_s.jpg" alt="Image 14" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="images/gallery/image_06_l.jpg" title="Lorem ipsum dolor sit amet, consectetur adipiscing elit.">
                        <img src="images/gallery/image_06_s.jpg" alt="Image 15" />
                        </a>
                    </li>
                   
                </ul>  
                <div class="cleaner"></div>
          </div>
            
            <div class="cleaner"></div>
		</div>
        
        <div class="cleaner"></div>
    </div> <!-- end of main -->
        
</div> <!-- end of wrapper -->

<?php
include("footer.php");
?>