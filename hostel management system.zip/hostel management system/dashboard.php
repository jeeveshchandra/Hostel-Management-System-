<?php
include("header.php");
?>
    
    <div id="templatemo_middle_subpage">
    	<h2><center><font color="#CC33CC" name="caliberi" > <strong><i>...........WELCOME.........</i></strong></center></h2>
        <p> <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"></p>
  </div>
        
    <div id="templatemo_main">

        <div class="col_w900 col_w900_last">
            <div id="gallery">
                <ul>
                    <li><a href="dashboard.php" title="Home"><img src="images/geehasuki/images.jpg" alt="Home" /></a></li>
                    <li>
                        <a href="registration.php" title="click to know more.">
                        <img src="images/geehasuki/download (4).jpg" alt="Image 2" />
                        </a>
                  </li>
                    <li>
                        <a href="viewrooms.php" title="click to know more.">
                        <img src="images/geehasuki/images (11).jpg" alt="Image 3" />
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery/image_04_l.jpg" title="click to know more..">
                        <img src="images/geehasuki/images (28).jpg" alt="Image 4" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="rooms.php" title="click to know more..">
                        <img src="images/geehasuki/images (10).jpg" alt="Image 5" />
                        </a>
                    </li>

                    <li>
                        <a href="changepassword.php" title="click to know more..">
                        <img src="images/geehasuki/images (8).jpg" alt="Image 6" />
                        </a>
                    </li>
                    <li>
                        <a href="feetype.php" title="click to know more..">
                        <img src="images/geehasuki/images (16).jpg" alt="Image 7" />
                        </a>
                  </li>
                    <li>
                        <a href="course.php" title="click to know more.">
                        <img src="images/geehasuki/images (12).jpg" alt="Image 8" />
                        </a>
                    </li>
                    <li>
                        <a href="block.php" title="click to know more..">
                        <img src="images/geehasuki/images (31).jpg" alt="Image 9" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="viewcourse.php" title="click to know more..">
                        <img src="images/geehasuki/images (13).jpg" alt="Image 10" />
                        </a>
                    </li>

                    <li>
                        <a href="fees.php" title="click to know more..">
                        <img src="images/geehasuki/images (15).jpg" alt="Image 11" />
                        </a>
                    </li>
                    <li>
                        <a href="students.php" title="click to know more..">
                        <img src="images/geehasuki/images (25).jpg" alt="Image 12" />
                        </a>
                  </li>
                    <li>
                        <a href="viewstudent.php" title="click to know more..">
                        <img src="images/geehasuki/images (18).jpg" alt="Image 13" />
                        </a>
                    </li>
                    <li>
                        <a href="employee.php" title="click to know more..">
                        <img src="images/geehasuki/images (17).jpg" alt="Image 14" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="viewcourse.php" title="click to know more..">
                        <img src="images/geehasuki/images (29).jpg" alt="Image 10" />
                        </a>
                    </li>

                    
                    <li>
                        <a href="viewbilling.php" title="click to know more..">
                        <img src="images/geehasuki/images (20).jpg" alt="Image 12" />
                        </a>
                  </li>
                    <li>
                        <a href="messbill.php" title="click to know more..">
                        <img src="images/geehasuki/images (22).jpg" alt="Image 13" />
                        </a>
                    </li>
                    <li>
                        <a href="viewblocks.php" title="click to know more..">
                        <img src="images/geehasuki/images (30).jpg" alt="Image 14" />
                        </a>
                    </li>
                    <li class="lmb">
                        <a href="billing.php" title="click to know more..">
                        <img src="images/geehasuki/images (21).jpg" alt="Image 10" />
                        </a>
                    </li>

                    <li>
                        <a href="messcard.php" title="click to know more..">
                        <img src="images/geehasuki/messcard.jpg" alt="Image 11" />
                        </a>
                    </li>
                    <li>
                        <a href="viewroomallot.php" title="click to know more..">
                        <img src="images/geehasuki/images (35).jpg" alt="Image 12" />
                        </a>
                  </li>
                    <li>
                        <a href="viewfees.php" title="click to know more..">
                        <img src="images/geehasuki/download (3).jpg" alt="Image 13" />
                        </a>
                    </li>
                    <li>
                        <a href="viewmesscard.php" title="click to know more.">
                        <img src="images/geehasuki/mess.jpg" alt="Image 14" />
                        </a>
                    </li>
                    
                   
              </ul>  
                <div class="cleaner"></div>
          </div>
            
            <div class="cleaner"></div>
		</div>
        
        <div class="cleaner"></div>
    </div>
</div> <!-- end of wrapper -->

<?php
include("footer.php");
?>