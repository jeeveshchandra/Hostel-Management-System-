<form method="post" action="">
 <table class="tftable" border="1">
<h2><u>HOSTEL MANAGEMENT SYSTEM</u></h2>
<tr>
<td width="150">Name:</td>&nbsp&nbsp;<td width="108">Bill No:</td></tr>&nbsp&nbsp&nbsp;<br>
<td>Block Information:</td></tr>
<td>Bill Type:</td>&nbsp&nbsp;<td>Paid Date:</td></tr>
<td>Paid Amount:</td>&nbsp&nbsp;<td>Status:</td>
</tr>
</table>
</form> 